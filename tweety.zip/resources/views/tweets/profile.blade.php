@extends('layouts.app')

@section('content')

<div class="">
    <div class="position-relative mb-0">
        <img class="img-fluid rounded-lg " src="http://localhost:81/tweety/public/images/header.jpg" alt="">

        <img src="{{asset('storage/'.$user->avatar)}}"
             alt="user" class="profile-photo-lg rounded-circle border-2 border-secondary
                    " height="60px" style="position: relative;bottom: 36px;left: 43%">

    </div>


</div >
<div>
    <div  class="float-left ">
        <h4> {{$user->name}}</h4>
      <span class="text-muted"><p>@ {{$user->username }}</p></span>
        <span class="text-success">Joined at : </span> <span>{{($user->created_at)?$user->created_at->diffForHumans():''}}</span>

    </div>
    @if(auth()->user()->id === $user->id)

    <a href="{{route('editprofile',$user->id)}}" class="float-right btn btn-warning">Edit Profile</a>
    <a href="{{route('verify')}}" class="float-right mr-2 btn btn-success">Verify Profile</a>

    @endif
    @if(auth()->user()->id != $user->id)
    <x-follow-button :user="$user"></x-follow-button>
    @endif
</div>


<div class="clearfix mb-0"></div>

<span class="font-weight-bold text-muted"> Bio :</span>
<p class="text-sm-left font-weight-lighter">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. At beatae commodi cumque dolore eum ex fuga iste iure necessitatibus odio
    , possimus quibusdam, quos saepe similique sunt ullam velit, veritatis voluptatum?
</p>


<hr>
@foreach($user->tweets as $tweet)
    <div class="card">
        <div class="card-header Featured bg-light ">
            <a href="{{route('profile',$tweet->user)}}">
                <img src="{{asset('storage/'.$tweet->user->avatar)}}"
                     alt="user" class="profile-photo-lg rounded-circle float-left
                    " height="30px">
            </a>
            <p class=" ml-5">{{$tweet->user->name}}</p>
        </div>
        <div class="card-body">
            <p class="card-text">{{$tweet->body}}</p>
            <hr>
            <a href="#" class="btn btn-primary">Like</a>
            <i class="far fa-thumbs-up"></i>
        </div>
    </div>

@endforeach

@endsection
