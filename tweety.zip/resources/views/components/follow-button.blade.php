<form action="{{route('follow',$user->id)}}" method="POST">
    @csrf

    <button class="float-right btn btn-primary mr-2">

        @if(auth()->user()->is_following($user))
            <i class="fas fa-user-minus"></i>
        @else
            <i class="fas fa-user-plus"></i>
        @endif

    </button>

</form>
