@extends('layouts.app')
@section('content')

   <div class="flex-column mb-2">
       <div class="d-flex justify-content-center mb-3">
           <h3 class="text-muted"> People You May Know</h3>
       </div>

       @foreach($users as $user)
           <div class="row" style="margin-bottom: 20px">
               <div class="col-md-2">
                   <a href=" {{route('profile',$user->username)}}">
                       <img src="{{asset('storage/avatars/'.'RyCjKkjiTb18VULobXig7wsNPhqCjGFZQy7IqbUx.jpg')}}" class="rounded-lg" height="50">
                   </a>
               </div>

               <div class="col-md-8 float-left">
                   <h4 style="margin-bottom: 1px" class="d-inline"> {{$user->name}}</h4>
               @if($user->is_following(auth()->user()))
                       <span class="badge badge-secondary">Follows you</span>

                   @endif
                   <br>
                   <small class="text-muted">{{'@'.$user->username}}</small>
               </div>
               <div class="col-md-2">
                   <x-follow-button :user="$user"></x-follow-button>
               </div>
           </div>
       @endforeach
       <div class="d-flex justify-content-center">
           {{$users->links()}}

       </div>
   </div>
@endsection
