@extends('layouts.app')

@section('content')
    <form action="{{route('patchprofile',$user->username)}}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PATCH')

        <div class="form-group">
            <label for="exampleFormControlInput1">Name</label>
            <input name="name" type="text" class="form-control"placeholder="" value="{{$user->name}}" required>
            @error('name')
            <p class="text-center text-danger"> {{$message}}</p>
            @enderror
        </div>

        <div class="form-group">
            <label for="exampleFormControlInput1">Username</label>
            <input name="username" type="text" class="form-control"placeholder="" value="{{$user->username}}" required>
            @error('username')
            <p class="text-center text-danger"> {{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Email</label>
            <input name ="email" type="email" class="form-control"placeholder="" value="{{$user->email}}" required>
            @error('email')
            <p class="text-center text-danger"> {{$message}}</p>
            @enderror
        </div>


        <div class="form-group">
            <label for="exampleFormControlInput1">Avatar</label>
            <input name ="avatar" type="file" class="form-control">
            @error('avatar')
            <p class="text-center text-danger"> {{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Password</label>
            <input name="password" type="password" class="form-control"placeholder="" required>
            @error('password')
            <p class="text-center text-danger"> {{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Confirm Password</label>
            <input name="password_confirmation" type="password" class="form-control"placeholder="" required>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary" >Save</button>
        </div>
    </form>
@endsection

