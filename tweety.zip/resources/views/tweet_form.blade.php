<div class=" border-bottom">
    <form method="POST" action="{{route('tweet')}}">
        @csrf
        <div class="form-group">

            <textarea class="bg-light form-control rounded-lg mb-2" name="tweet" id="" cols="30" rows="5" placeholder="What`s On Your Mind..."></textarea>
            <hr>
            <div class="col-md-2  col-sm-2 d-inline mt-2">
                <img src="{{asset('storage/'.auth()->user()->avatar)}}" alt="user" class="profile-photo-lg rounded-circle " height="30px">
            </div>

            <button class=" btn btn-primary float-right"> Tweet</button>
        </div>

    </form>
    @error('tweet')
    <p class="text-center text-danger"> {{$message}}</p>
    @enderror
</div>
