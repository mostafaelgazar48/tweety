@extends('layouts.app')

@section('content')
    @include('tweet_form')

    <div  style=" border:1px ;border-color: gray">
        @foreach($tweets as $tweet)
            @include('tweets')
        @endforeach
    </div>
@endsection
