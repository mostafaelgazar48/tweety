
    <div class="card" style="{{ session('theme' )=='darkly'?'color:white;background:black':'color:black;background-color:white'}}">
        <div class="card-header Featured bg-light ">
            <a href="{{route('profile',$tweet->user)}}">
                <img src="{{asset('storage/'.$tweet->user->avatar)}}"
                     alt="user" class="profile-photo-lg rounded-circle float-left
                    " height="30px">
            </a>
                    <p class=" ml-5">{{$tweet->user->name}}</p>
    </div>
        <div class="card-body">
            <p class="card-text">{{$tweet->body}}</p>
            <hr>
            <div class="d-flex">
                    <form action="/tweety/public/tweets/{{$tweet->id}}/like" method="POST">
@csrf
                        <div class="d-inline">
                            <button class="btn btn-secondary far fa-thumbs-up"></button>
                            <span> {{$tweet->likes ?:0}}</span>
                        </div>

                    </form>
                    <form action="/tweety/public/tweets/{{$tweet->id}}/like" method="POST">
                        @csrf
                        @method('DELETE')
                        <div class="d-inline ml-5">
                            <button class="btn btn-secondary far fa-thumbs-down"></button>
                            <span> {{$tweet->dislikes?:0}}</span>
                        </div>
                     </form>
            </div>
        </div>
    </div>
